ClosedCube Arduino Library for
ClosedCube HDC1080 Low Power High Accuracy Digital I2C Humidity and Temperature Sensor Breakout
=================================================================

This is breakout board for [Texas Instruments HDC1080](http://www.ti.com/product/HDC1080) Low Power High Accuracy Digital Humidity Sensor with Temperature Sensor 


[![](https://github.com/closedcube/ClosedCube_HDC1080_Arduino/blob/master/images/B004_HDC1080_Pic1.jpg)](https://www.tindie.com/stores/closedcube/)
[![](https://github.com/closedcube/ClosedCube_HDC1080_Arduino/blob/master/images/B004_HDC1080_Pic2.jpg)](https://www.tindie.com/stores/closedcube/)




